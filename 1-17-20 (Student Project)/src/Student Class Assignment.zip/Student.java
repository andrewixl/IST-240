
public class Student {
	private String givenName;
	private String familyName;
	private int age;
	private float gpa;
	
	public Student(String givenNameIn, String familyNameIn)
	{
		givenName = givenNameIn;
		familyName = familyNameIn;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getGpa() {
		return gpa;
	}

	public void setGpa(float gpa) {
		this.gpa = gpa;
	}
	
}
