
public enum AddressType {
	TEMPORARY,
	PERMANENT,
	LOCAL,
}
