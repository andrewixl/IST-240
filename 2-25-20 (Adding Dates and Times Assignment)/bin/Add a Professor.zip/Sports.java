
public enum Sports {
	BASEBALL,
	FOOTBALL,
	DIVING,
	SWIMMING,
	WRESTLING,
	VOLLEYBALL,	
}
